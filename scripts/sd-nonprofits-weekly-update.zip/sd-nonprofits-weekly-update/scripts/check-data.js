// Publish guard: compares the freshly built dashboard data against the
// version currently committed. If an API outage or partial fetch made the
// numbers collapse, this exits non-zero so the workflow stops BEFORE
// committing — the live site keeps last week's good data, and GitHub
// emails a failure notice instead.

import { readFileSync } from 'fs';
import { execSync } from 'child_process';

const FILE = 'src/data/dashboard-data.json';
const MAX_DROP = 0.10; // allow normal churn; block anything bigger than a 10% drop

const next = JSON.parse(readFileSync(FILE, 'utf-8'));

let prev = null;
try {
  prev = JSON.parse(execSync(`git show HEAD:${FILE}`, { maxBuffer: 256 * 1024 * 1024 }).toString());
} catch {
  console.log('No committed baseline found; skipping comparison.');
}

const problems = [];
const n = next.overview || {};
if (!n.total_orgs || !Array.isArray(next.orgs) || next.orgs.length === 0) {
  problems.push('New data is empty or malformed.');
}

if (prev?.overview) {
  for (const key of ['total_orgs', 'with_financials']) {
    const before = prev.overview[key];
    const after = n[key];
    if (typeof before !== 'number' || before === 0) continue;
    const change = (after - before) / before;
    console.log(`${key}: ${before} -> ${after} (${(change * 100).toFixed(1)}%)`);
    if (change < -MAX_DROP) {
      problems.push(`${key} dropped ${(change * -100).toFixed(1)}% (${before} -> ${after}), over the ${MAX_DROP * 100}% limit.`);
    }
  }
}

if (problems.length) {
  console.error('\nNot publishing — data failed the safety check:');
  for (const p of problems) console.error(`  - ${p}`);
  console.error('\nIf this drop is real (e.g., a mass IRS revocation), run the workflow manually with "skip_guard" checked.');
  process.exit(1);
}
console.log('Safety check passed.');
